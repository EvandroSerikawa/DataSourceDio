package one.digitainnovationation.desafioAcademia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioAcademiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafioAcademiaApplication.class, args);
	}

}
